import React, { useState } from 'react';
import { 
  BookOpen, 
  Plus, 
  Edit2, 
  Trash2, 
  X, 
  Check, 
  AlertCircle 
} from 'lucide-react';
import { Subject, Task } from '../types';
import { api } from '../services/api';
import { PrimaryButton, SecondaryButton, ConfirmDeleteDialog, LoadingState } from '../components/common';

export function SubjectsScreen({
  subjects,
  tasks,
  loading,
  onRefresh,
  onClose,
}: {
  subjects: Subject[];
  tasks: Task[];
  loading: boolean;
  onRefresh: () => void;
  onClose?: () => void;
}) {
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [subjectToDelete, setSubjectToDelete] = useState<Subject | null>(null);

  // Form fields
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [facultyName, setFacultyName] = useState('');
  const [academicWeight, setAcademicWeight] = useState(4);
  const [color, setColor] = useState('#4f46e5');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const colors = [
    '#4f46e5', // Indigo
    '#0d9488', // Teal
    '#ea580c', // Orange
    '#7c3aed', // Purple
    '#e11d48', // Rose
    '#0284c7', // Sky
    '#16a34a', // Emerald
    '#d97706', // Amber
  ];

  const handleOpenCreate = () => {
    setName('');
    setCode('');
    setFacultyName('');
    setAcademicWeight(4);
    setColor('#4f46e5');
    setError(null);
    setIsCreating(true);
    setEditingSubject(null);
  };

  const handleOpenEdit = (sub: Subject) => {
    setName(sub.name);
    setCode(sub.code);
    setFacultyName(sub.facultyName);
    setAcademicWeight(sub.academicWeight);
    setColor(sub.color || '#4f46e5');
    setError(null);
    setEditingSubject(sub);
    setIsCreating(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Subject Name is required.');
      return;
    }

    setSaving(true);
    try {
      if (editingSubject) {
        await api.subjects.update(editingSubject.id, {
          name: name.trim(),
          code: code.trim().toUpperCase(),
          facultyName: facultyName.trim(),
          academicWeight: Number(academicWeight),
          color,
        });
      } else {
        await api.subjects.create({
          name: name.trim(),
          code: code.trim().toUpperCase(),
          facultyName: facultyName.trim(),
          academicWeight: Number(academicWeight),
          color,
        });
      }
      onRefresh();
      setIsCreating(false);
      setEditingSubject(null);
    } catch (err: any) {
      setError(err.message || 'Failed to save subject.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await api.subjects.delete(id);
      onRefresh();
    } catch (err) {
      console.error('Failed to delete subject:', err);
    }
  };

  const totalCredits = subjects.reduce((acc, s) => acc + (s.academicWeight || 0), 0);

  return (
    <div className="space-y-6 pb-12">
      {/* Desktop Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <BookOpen className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
            <span>Course Subjects</span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {subjects.length} enrolled courses · {totalCredits} total academic credits configured
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Course Subject</span>
          </button>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Subject Grid */}
      {loading ? (
        <LoadingState message="Loading course subjects..." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {subjects.map((sub) => {
            const subjectTasks = tasks.filter((t) => t.subjectId === sub.id);
            const pendingCount = subjectTasks.filter((t) => t.status !== 'Completed').length;
            const completedCount = subjectTasks.filter((t) => t.status === 'Completed').length;
            const totalCount = subjectTasks.length;
            const completionPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

            return (
              <div
                key={sub.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col justify-between gap-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div
                      className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-xs shrink-0"
                      style={{ backgroundColor: sub.color || '#4f46e5' }}
                    >
                      {sub.code ? sub.code.slice(0, 4) : sub.name.slice(0, 2).toUpperCase()}
                    </div>

                    <div className="min-w-0">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                        {sub.name}
                      </h4>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mt-1">
                        {sub.code && <span className="font-mono">{sub.code}</span>}
                        {sub.code && <span>·</span>}
                        <span>{sub.academicWeight} Credits</span>
                      </div>
                      {sub.facultyName && (
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                          Faculty: Prof. {sub.facultyName}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(sub)}
                      className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                      title="Edit Course"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubjectToDelete(sub)}
                      className="p-2 rounded-xl text-rose-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                      title="Delete Course"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                      {pendingCount} active deadline{pendingCount === 1 ? '' : 's'}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 font-mono">
                      {completedCount}/{totalCount} completed ({completionPct}%)
                    </span>
                  </div>
                  <div className="h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${completionPct}%`,
                        backgroundColor: sub.color || '#4f46e5',
                      }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create / Edit Modal */}
      {(isCreating || editingSubject) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingSubject ? 'Edit Subject' : 'Add New Course Subject'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setIsCreating(false);
                  setEditingSubject(null);
                }}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 pt-4 text-xs">
              {error && (
                <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Subject Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Operating Systems"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Course Code
                  </label>
                  <input
                    type="text"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="CS201"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs uppercase font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Faculty Name
                  </label>
                  <input
                    type="text"
                    value={facultyName}
                    onChange={(e) => setFacultyName(e.target.value)}
                    placeholder="Dr. K. Ramanathan"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Academic Credit Weight ({academicWeight} Credits)
                </label>
                <div className="grid grid-cols-5 gap-1.5">
                  {[1, 2, 3, 4, 5].map((w) => (
                    <button
                      key={w}
                      type="button"
                      onClick={() => setAcademicWeight(w)}
                      className={`py-2 rounded-lg font-bold text-xs cursor-pointer ${
                        academicWeight === w
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {w} cr
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                  Theme Color Badge
                </label>
                <div className="flex items-center gap-2.5">
                  {colors.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className="w-7 h-7 rounded-full flex items-center justify-center transition-transform hover:scale-110 cursor-pointer"
                      style={{ backgroundColor: c }}
                    >
                      {color === c && <Check className="w-4 h-4 text-white stroke-[3]" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex gap-2">
                <SecondaryButton
                  onClick={() => {
                    setIsCreating(false);
                    setEditingSubject(null);
                  }}
                  className="flex-1"
                >
                  Cancel
                </SecondaryButton>
                <PrimaryButton type="submit" loading={saving} className="flex-1">
                  {editingSubject ? 'Save Changes' : 'Create Subject'}
                </PrimaryButton>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirm Delete Dialog */}
      <ConfirmDeleteDialog
        isOpen={Boolean(subjectToDelete)}
        onClose={() => setSubjectToDelete(null)}
        onConfirm={() => {
          if (subjectToDelete) handleDelete(subjectToDelete.id);
        }}
        title="Delete Course Subject?"
        message={`Are you sure you want to remove "${subjectToDelete?.name}"? Associated tasks will remain in your database.`}
      />
    </div>
  );
}
